//
//  EBConfig.m
//  PrictiseProduct
//
//  Created by JasonTang on 2018/8/1.
//  Copyright © 2018年 ___JasonTang___. All rights reserved.
//

#import "EBConfig.h"

/* ---------------------------- 公共参数配置 ---------------------------- */
NSString *const user_agent      = @"EB_IPHONE PrictiseProduct/";
NSString *const accept_value    = @"text/html";
NSString *const content_type    = @"text/html";

/* sign标签 */
NSString *const SIGN_KEY = @"";
/* 密码加密标签 */
NSString *const PASSWORD_KEY = @"";
/* 渠道号 */
NSString *const EBConfigChannel = @"";
/* 公司机构号 */
NSString *const EBConfigTenantId = @"0000000000";
/* 请求超时时间 */
NSInteger const EBConfigDefaultNetworkTimeOut = 20;
/* 文件流类的网络请求超时时间 */
NSInteger const EBConfigUpFileNetworkTimeOut  = 30;
/* sms 重发时间 */
NSInteger const EBConfigDefaultSMSCountDownTime = 60;
/* 默认保留金额多少位小数 */
NSInteger const EBConfigDefaultNSDecimalNumberScale = 5;
/* YES:四舍五入 NO:截取 */
BOOL const isNSDecimalNumberRounded = YES;
/* 代理IP */
NSString *const EBConfigkSCPropNetProxiesHTTPProxy = @"";
/* 代理端口号 */
NSString *const EBConfigkSCPropNetProxiesHTTPSProxy = @"";

/* ---------------第三方key--------------- */
NSString *const EB_UM_AppKey            = @"";        //友盟分享Key
NSString *const EB_UM_Sina_AppKey       = @"";
NSString *const EB_UM_Sina_AppSecret    = @"";
NSString *const EB_UM_QQ_AppId          = @"";
NSString *const EB_UM_QQ_AppKey         = @"";
NSString *const EB_UM_WX_AppID          = @"";
NSString *const EB_UM_WX_AppSecret      = @"";
NSString *const EB_UM_Share_Url         = @"";

/* ---------------其他URL配置--------------- */
//资讯分享-安装二维码地址
NSString *const EB_QrCode_installation_URL = @"";

/* ---------------------------- 开发环境配置 ---------------------------- */
#if defined(DEV_ENV_0)

BOOL const isAllowInvalidCertificate = NO;

/* 生产测试环境切换的日期控制，在THIRDPARTYLOGINDISPLAYDATE日期之前走测试环境，之后恢复生产环境 */
NSString *const THIRDPARTYLOGINDISPLAYDATE = @"2017-10-18 18:10:00";

// 生成邀请二维码地址
NSString *const EB_QrCode_invitation_URL = @"";
// 资讯地址
NSString *const EBDefaultInformationUrl  = @"";
// H5
NSString *const EBDefaultInformationHTML = @"";

/* 极光推送:开发环境：0 生产环境：1 */
NSInteger const EBApplicationApsForProduction = 0;

/* 备用环境地址 */
NSString *const EBDefaultServerUrlUAT = @"";

#if defined(UAT_PC_Z)
NSString *const EBDefaultServerUrl = @"";

#endif


/* ---------------------------- 测试环境配置 ---------------------------- */
#elif defined(DEV_ENV_1)

BOOL const isAllowInvalidCertificate = NO;

/* 生产测试环境切换的日期控制，在THIRDPARTYLOGINDISPLAYDATE日期之前走测试环境，之后恢复生产环境 */
NSString *const THIRDPARTYLOGINDISPLAYDATE = @"2017-10-18 18:10:00";

//生成邀请二维码地址
NSString *const EB_QrCode_invitation_URL = @"";
//资讯地址
NSString *const EBDefaultInformationUrl  = @"";
//H5
NSString *const EBDefaultInformationHTML = @"";

/* 极光推送:开发环境：0 生产环境：1 */
NSInteger const EBApplicationApsForProduction = 0;

/* 备用环境地址 */
NSString *const EBDefaultServerUrlUAT = @"";

#if defined(UAT_PC) //连UAT（内网）
NSString *const EBDefaultServerUrl = @"";
#elif defined(UAT_PC_W)//连UAT（外网）
NSString *const EBDefaultServerUrl = @"";

#endif


/* ---------------------------- 生产环境配置 ---------------------------- */
#else


BOOL const isAllowInvalidCertificate = YES;

/* 生产测试环境切换的日期控制，在THIRDPARTYLOGINDISPLAYDATE日期之前走测试环境，之后恢复生产环境 */
NSString *const THIRDPARTYLOGINDISPLAYDATE = @"2018-04-28 23:59:59";

//生成邀请二维码地址
NSString *const EB_QrCode_invitation_URL = @"";
//资讯地址
NSString *const EBDefaultInformationUrl  = @"";
//H5
NSString *const EBDefaultInformationHTML = @"";

/* 极光推送:开发环境：0 生产环境：1 */
NSInteger const EBApplicationApsForProduction = 1;

/* 生产域名地址 */
NSString *const EBDefaultServerUrl = @"";

/* 备用环境地址 */
NSString *const EBDefaultServerUrlUAT = @"";


#endif

