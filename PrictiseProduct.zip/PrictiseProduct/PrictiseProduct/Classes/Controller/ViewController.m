//
//  ViewController.m
//  PrictiseProduct
//
//  Created by JasonTang on 2018/8/1.
//  Copyright © 2018年 ___JasonTang___. All rights reserved.
//

#import "ViewController.h"
#import "EBCostomCalendarView.h"

@interface ViewController ()<EBCostomCalendarViewDelegate>

@property (nonatomic , strong) EBCostomCalendarView *calendarView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self.view addSubview:self.calendarView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (EBCostomCalendarView *)calendarView {
    if (!_calendarView) {
        _calendarView = [[EBCostomCalendarView alloc]initWithFrame:CGRectMake(0, 200, self.view.frame.size.width, 60.f)];
        _calendarView.backgroundColor = [UIColor whiteColor];
        _calendarView.delegate = self;
    }
    return _calendarView;
}

- (void)didSelectDate:(NSMutableArray *)dateArr selectDate:(NSDate *)date {
    
}

@end
