////
//  EBCostomCalendarItem.m
//  PrictiseProduct
//
//  Created by Mac on 2020/3/9.
//  Copyright © 2020 ___JasonTang___. All rights reserved.
//

#import "EBCostomCalendarItem.h"
#import "EBViewExt.h"

@implementation EBCostomCalendarItem

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initOtherUI];
        [self createView];
    }
    return self;
}
- (void)initOtherUI {
    _norColor = [UIColor blackColor];//默认颜色
    _norBgColor = [UIColor whiteColor];//默认背景颜色

    _norSelectColor = [UIColor redColor];//默认选中颜色
    _norSelectBgColor = [UIColor whiteColor];//默认选中背景颜色

    _selectColor = [UIColor whiteColor];//手动选中颜色
    _selectBgColor = [UIColor orangeColor];//手动选中背景颜色
}
- (void)setNorColor:(UIColor *)norColor {
    _norColor = norColor;
}
- (void)setNorBgColor:(UIColor *)norBgColor {
    _norBgColor = norBgColor;
}
-(void)setNorSelectColor:(UIColor *)norSelectColor {
    _norSelectColor = norSelectColor;
}
- (void)setNorSelectBgColor:(UIColor *)norSelectBgColor {
    _norSelectBgColor = norSelectBgColor;
}
- (void)setSelectColor:(UIColor *)selectColor {
    _selectColor = selectColor;
}
- (void)setSelectBgColor:(UIColor *)selectBgColor {
    _selectBgColor = selectBgColor;
}
- (void)createView{
    self.dateButtonArray = [NSMutableArray array];
    CGFloat W  = self.frame.size.width/7;
    for (NSInteger i = 0; i<7; i++) {
        UILabel *label = [[UILabel alloc] init];
        
        label.frame = CGRectMake(0, 0, self.height, self.height);
        label.center = CGPointMake(W/2 + W*i, self.height / 2);
        label.backgroundColor = self.norBgColor;
        label.layer.cornerRadius = self.height/2;
        label.layer.masksToBounds = YES;
        label.numberOfLines = 0;
        label.tag = i+1000;
        label.font = [UIFont systemFontOfSize:12];
        label.textAlignment = NSTextAlignmentCenter;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        label.userInteractionEnabled = YES;
        [label addGestureRecognizer:tap];
        [self addSubview:label];
        [self.dateButtonArray addObject:label];
    }
}

- (void)reloadButtonTitle:(NSMutableArray *)arr nsDateArr:(NSMutableArray *)dateArr selectDate:(NSDate *)selectDate{
    [self setButtonTitle:arr nsDateArr:dateArr secectDate:selectDate];
}
- (void)setButtonTitle:(NSMutableArray *)dateArr nsDateArr:(NSMutableArray *)dateArray secectDate:(NSDate *)selectdate{
    self.dateArr = dateArr;
    self.nsdateArr = dateArray;
    for (NSInteger i = 0; i<dateArr.count; i++) {
        UILabel *label = self.dateButtonArray[i];
        NSString *title = [self getButtonTitle:dateArr[i]];
        label.text = title;
   
    
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyyMMdd"];

        if ([[formatter stringFromDate:[NSDate date]] isEqualToString:[formatter stringFromDate:dateArray[i]]]) {
            /// 是当天时间被选中
            if ([[formatter stringFromDate:selectdate] isEqualToString:[formatter stringFromDate:dateArray[i]]]) {
                // 手动选中
                label.backgroundColor = self.selectBgColor;
                label.textColor = self.selectColor;
            }else{
                // 默认选中
                label.backgroundColor = self.norSelectBgColor;
                label.textColor = self.norSelectColor;
            }
        }else{
            /// 不是当前时间被选中
            if ([[formatter stringFromDate:selectdate] isEqualToString:[formatter stringFromDate:dateArray[i]]]) {
                label.backgroundColor = self.selectBgColor;
                label.textColor = self.selectColor;
            }else{
                label.backgroundColor = self.norBgColor;
                label.textColor = self.norColor;
            }
        }
    }
}

- (void)tapAction:(UITapGestureRecognizer *)tap{
    [self.delegate didSelectDate:self.dateArr[tap.view.tag-1000] selectDate:self.nsdateArr[tap.view.tag-1000]];
//    NSLog(@"====点击了%@",self.dateArr[tap.view.tag-1000]);
    self.selectedDate = self.nsdateArr[tap.view.tag-1000];
    for (NSInteger i = 0; i<self.dateButtonArray.count; i++) {
        UILabel *label = self.dateButtonArray[i];
        if (i == tap.view.tag-1000) {
            label.backgroundColor = self.selectBgColor;
            label.textColor = self.selectColor;
        }else{
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyyMMdd"];
            if ([[formatter stringFromDate:[NSDate date]] isEqualToString:[formatter stringFromDate:self.nsdateArr[i]]]) {
                label.backgroundColor = self.norSelectBgColor;
                label.textColor = self.norSelectColor;
            }else{
                label.backgroundColor = self.norBgColor;
                label.textColor = self.norColor;
            }
        }
    }
}
- (NSString *)getButtonTitle:(NSArray *)arr{
    return [NSString stringWithFormat:@"%@",arr[2]];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


@end
