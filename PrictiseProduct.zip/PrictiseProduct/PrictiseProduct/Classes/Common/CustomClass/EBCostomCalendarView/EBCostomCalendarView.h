////
//  EBCostomCalendarView.h
//  PrictiseProduct
//
//  Created by Mac on 2020/3/9.
//  Copyright © 2020 ___JasonTang___. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol EBCostomCalendarViewDelegate<NSObject>

- (void)didSelectDate:(NSMutableArray *)dateArr selectDate:(NSDate *)date;

@end

@interface EBCostomCalendarView : UIView

@property (nonatomic, weak) id<EBCostomCalendarViewDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
