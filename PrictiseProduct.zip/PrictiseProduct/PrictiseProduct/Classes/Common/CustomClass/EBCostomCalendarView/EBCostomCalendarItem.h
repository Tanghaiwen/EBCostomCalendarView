////
//  EBCostomCalendarItem.h
//  PrictiseProduct
//
//  Created by Mac on 2020/3/9.
//  Copyright © 2020 ___JasonTang___. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol EBCostomCalendarItemDelegate<NSObject>

- (void)didSelectDate:(NSMutableArray *)dateArr selectDate:(NSDate *)date;

@end

@interface EBCostomCalendarItem : UIView

@property (nonatomic, strong) NSMutableArray *dateButtonArray;
- (void)reloadButtonTitle:(NSMutableArray *)arr nsDateArr:(NSMutableArray *)dateArr selectDate:(NSDate *)selectDate;

@property (nonatomic, strong) NSMutableArray *dateArr;
@property (nonatomic, strong) NSMutableArray *nsdateArr;
@property (nonatomic, strong) NSDate *selectedDate;

@property (nonatomic, strong) UIColor *norColor;//默认颜色
@property (nonatomic, strong) UIColor *norBgColor;//默认背景颜色

@property (nonatomic, strong) UIColor *norSelectColor;//默认选中颜色
@property (nonatomic, strong) UIColor *norSelectBgColor;//默认选中背景颜色

@property (nonatomic, strong) UIColor *selectColor;//手动选中颜色
@property (nonatomic, strong) UIColor *selectBgColor;//手动选中背景颜色

@property (nonatomic, weak) id<EBCostomCalendarItemDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
