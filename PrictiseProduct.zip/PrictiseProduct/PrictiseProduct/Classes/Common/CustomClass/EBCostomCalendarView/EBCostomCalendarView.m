////
//  EBCostomCalendarView.m
//  PrictiseProduct
//
//  Created by Mac on 2020/3/9.
//  Copyright © 2020 ___JasonTang___. All rights reserved.
//

#import "EBCostomCalendarView.h"
#import "EBCostomCalendarItem.h"

@interface EBCostomCalendarView()<UIScrollViewDelegate,EBCostomCalendarItemDelegate>

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) NSMutableArray *dateArray;
@property (nonatomic, strong) NSMutableArray *nsDateArray;
@property (nonatomic, strong) EBCostomCalendarItem *dateView;
@property (nonatomic, strong) NSMutableArray *dateViewArr;
@property (nonatomic, strong) UIScrollView *backScrollView;
@property (nonatomic, assign) CGFloat contentOffsetX;
@property (nonatomic, strong) NSDate *selectDate;

@end

@implementation EBCostomCalendarView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self createView];
    }
    return self;
}
- (void)createView{

    self.nsDateArray = [NSMutableArray array];
    self.dateArray = [NSMutableArray array];
    
    NSArray *weekArr = @[@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六"];
    for (NSInteger i = 0; i<7; i++) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(i*self.frame.size.width/7, 0, self.frame.size.width/7, 30)];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:12];
        label.text = weekArr[i];
        [self addSubview:label];
    }
    self.backScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 30, self.frame.size.width, 30)];
    self.backScrollView.contentSize = CGSizeMake(self.frame.size.width*3, 0);
    [self addSubview:self.backScrollView];
    self.backScrollView.delegate = self;
    self.backScrollView.pagingEnabled = YES;
    self.backScrollView.showsHorizontalScrollIndicator = NO;
    self.dateViewArr = [NSMutableArray array];
    /// 总共三页视图，显示前一个星期，当前星期和后一个星期的数据
    for (NSInteger i = 0; i<3; i++) {
        self.dateView = [[EBCostomCalendarItem alloc] initWithFrame:CGRectMake(self.frame.size.width*i, 0, self.frame.size.width, 30)];
        self.dateView.delegate = self;
        [self.backScrollView addSubview:self.dateView];
        [self.dateViewArr addObject:self.dateView];
    }
    [self setorigindata];
    [self setScrollViewContentOffsetCenter];
}
// 获取前一页日期数组
- (NSMutableArray *)getleftweekdate{
    NSMutableArray *weekdateArray = [NSMutableArray array];
    NSMutableArray *dateArray = [NSMutableArray array];
    NSMutableArray *nsdateArray = [NSMutableArray array];
    NSDate *date = [self.nsDateArray firstObject];
    for (NSInteger i = 1; i<=7; i++) {
        NSDate *lastDay = [NSDate dateWithTimeInterval:-24*60*60*i sinceDate:date];//前i天
        // 类型为nsdate 的日期数组
        [dateArray insertObject:[self getDateArr:lastDay] atIndex:0];
        // 类型为年月日星期 字符串数组的数组
        [nsdateArray insertObject:lastDay atIndex:0];
    }
    [weekdateArray addObject:dateArray];
    [weekdateArray addObject:nsdateArray];
    return weekdateArray;
}
// 获取后一页日期数组
- (NSMutableArray *)getrightweekdate{
    NSMutableArray *weekdateArray = [NSMutableArray array];
    NSMutableArray *dateArray = [NSMutableArray array];
    NSMutableArray *nsdateArray = [NSMutableArray array];
    NSDate *date = [self.nsDateArray lastObject];
    for (NSInteger i = 1; i<=7; i++) {
        NSDate *lastDay = [NSDate dateWithTimeInterval:+24*60*60*i sinceDate:date];//后i天
        [dateArray addObject:[self getDateArr:lastDay]];
        [nsdateArray addObject:lastDay];
    }
    [weekdateArray addObject:dateArray];
    [weekdateArray addObject:nsdateArray];
    return weekdateArray;
}
/// 偏移到中心位置
- (void)setScrollViewContentOffsetCenter {
    [self.backScrollView setContentOffset:CGPointMake(self.frame.size.width, 0) animated:NO];
}
  
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    int contentOffsetX = scrollView.contentOffset.x;
    /// 右划
    if(contentOffsetX >= (2 * self.frame.size.width)) {
        [self scrollActionwithdirection:1];
        [self reloadfistandlastdata];
        [self.backScrollView setContentOffset:CGPointMake(self.frame.size.width, 0)];
    }
    /// 左滑
    if(contentOffsetX <= 0) {
        [self scrollActionwithdirection:0];
        [self reloadfistandlastdata];
        [self.backScrollView setContentOffset:CGPointMake(self.frame.size.width, 0)];
    }
}
- (void)reloadfistandlastdata{
    /// 刷新前一页日期
    [self.dateViewArr[0] reloadButtonTitle:[self getleftweekdate].firstObject nsDateArr:[self getleftweekdate].lastObject selectDate:self.selectDate];
    /// 刷新中间页日期
    [self.dateViewArr[1] reloadButtonTitle:self.dateArray nsDateArr:self.nsDateArray selectDate:self.selectDate];
    /// 刷新后一页日期
    [self.dateViewArr[2] reloadButtonTitle:[self getrightweekdate].firstObject nsDateArr:[self getrightweekdate].lastObject selectDate:self.selectDate];
    
}
// 点击标题回到当前这一星期
- (void)titleTapAction{
    [self setorigindata];
}
// 设置初始时间
- (void)setorigindata{
    NSInteger a = 0;
    NSInteger b = 0;
    if ([self getNowWeek] == 1){
        a = 0;
        b = 6;
    }else{
        a = [self getDayChafromMonday:[self getNowWeek]]+1;
        b = [self getDayChaToSunday:[self getNowWeek]]-1;
    }
    /// 当前星期格式化时间(年月日星期的数组)
    self.dateArray = [self getDateArrCarFro:a chaTo:b type:0];
    /// 当前星期标准时间 （nsdate）
    self.nsDateArray = [self getDateArrCarFro:a chaTo:b type:1];
    //
    [self reloadfistandlastdata];
}
- (void)scrollActionwithdirection:(NSInteger)type{
    // type = 0 左划。type = 1 右划
    if (type == 0){
        NSDate *date = [self.nsDateArray firstObject];
        [self.dateArray removeAllObjects];
        [self.nsDateArray removeAllObjects];
        for (NSInteger i = 1; i<=7; i++) {
            NSDate *lastDay = [NSDate dateWithTimeInterval:-24*60*60*i sinceDate:date];//前i天
            [self.dateArray insertObject:[self getDateArr:lastDay] atIndex:0];
            [self.nsDateArray insertObject:lastDay atIndex:0];
        }
    }else{
        NSDate *date = [self.nsDateArray lastObject];
        [self.dateArray removeAllObjects];
        [self.nsDateArray removeAllObjects];
        for (NSInteger i = 1; i<=7; i++) {
            NSDate *lastDay = [NSDate dateWithTimeInterval:+24*60*60*i sinceDate:date];//前i天
            [self.dateArray addObject:[self getDateArr:lastDay]];
            [self.nsDateArray addObject:lastDay];
        }
    }
}
- (void)didSelectDate:(NSMutableArray *)dateArr selectDate:(NSDate *)date{
    [self.delegate didSelectDate:dateArr selectDate:date];
    self.selectDate = date;
    [self reloadfistandlastdata];
}
//// 获取当前这个星期格式化的时间(type = 0)         /             标准时间(type = 1)
- (NSMutableArray *)getDateArrCarFro:(NSInteger)chafro chaTo:(NSInteger)chato type:(NSInteger)type{
    NSMutableArray *dateArr = [NSMutableArray array];
    NSMutableArray *nsdateArr = [NSMutableArray array];
    for (NSInteger i = 1; i<=chafro; i++) {
        NSDate * date = [NSDate date];//当前时间
        NSDate *lastDay = [NSDate dateWithTimeInterval:-24*60*60*i sinceDate:date];//前i天
        [dateArr insertObject:[self getDateArr:lastDay] atIndex:0];
        [nsdateArr insertObject:lastDay atIndex:0];
    }
    [dateArr addObject:[self getDateArr:[NSDate date]]];
    [nsdateArr addObject:[NSDate date]];
    for (NSInteger i = 1; i<=chato; i++) {
        NSDate * date = [NSDate date];//当前时间
        NSDate *lastDay = [NSDate dateWithTimeInterval:+24*60*60*i sinceDate:date];//后i天
        [dateArr addObject:[self getDateArr:lastDay]];
        [nsdateArr addObject:lastDay];
    }
    if (type == 0) {
        return dateArr;
    }else{
        return nsdateArr;
    }
}
//
- (NSDateComponents *)getNowDateComponents:(NSDate *)date{
    //获取系统当前的时间
    NSCalendar *cal=[NSCalendar  currentCalendar];
    NSUInteger unitFlags= NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitWeekday|NSCalendarUnitWeekOfMonth|NSCalendarUnitWeekOfYear|NSCalendarUnitWeekday;
    NSDateComponents *conponent= [cal components:unitFlags fromDate:date];
    return conponent;
}
//// 获取当前日期 显示为标题时间
- (NSString *)getNowDate:(NSDate *)senddate{
    NSDateComponents *conponent= [self getNowDateComponents:senddate];
    //获取年、月、日
    NSInteger year =  [conponent year];
    NSInteger month = [conponent month];
    NSInteger day   = [conponent day];
    //周
     NSInteger week   = [conponent weekday];
    NSString *dateStr = [NSString stringWithFormat:@"%ld年%ld月%ld日 %@",year,month,day,[self getWeekChinese:week]];
    return dateStr;
}
//根据传进来的date 返回一个由 年，月，日 星期组成的数组。。。。
- (NSArray *)getDateArr:(NSDate *)senddate{
    NSDateComponents *conponent= [self getNowDateComponents:senddate];
    //获取年、月、日
    NSInteger year =  [conponent year];
    NSInteger month = [conponent month];
    NSInteger day   = [conponent day];
    //周
    NSInteger week   = [conponent weekday];
    NSArray *arr = @[[NSString stringWithFormat:@"%ld",year],[NSString stringWithFormat:@"%ld",month],[NSString stringWithFormat:@"%ld",day],[self getWeekChinese:week]];
    return arr;
}
/// 获取当前这天是星期几
- (NSInteger)getNowWeek{
    NSDateComponents *conponent= [self getNowDateComponents:[NSDate date]];
       //周
       NSInteger week =  [conponent weekday];
    return week;
}

/// 计算当前这天与周一相差几天
- (NSInteger)getDayChafromMonday:(NSInteger)week{
    if (week == 2) {
        return 0;
    }else if (week == 3){
        return 1;
    }else if (week == 4){
        return 2;
    }else if (week == 5){
        return 3;
    }else if (week == 6){
        return 4;
    }else if (week == 7){
        return 5;
    }else{
        return 6;
    }
}
/// 计算当前这天与周日相差几天
- (NSInteger)getDayChaToSunday:(NSInteger)week{
    if (week == 2) {
        return 6;
    }else if (week == 3){
        return 5;
    }else if (week == 4){
        return 4;
    }else if (week == 5){
        return 3;
    }else if (week == 6){
        return 2;
    }else if (week == 7){
        return 1;
    }else{
        return 0;
    }
}


- (NSString *)getWeekChinese:(NSInteger)week{
    if (week == 2) {
        return @"周一";
    }else if (week == 3){
        return @"周二";
    }else if (week == 4){
        return @"周三";
    }else if (week == 5){
        return @"周四";
    }else if (week == 6){
        return @"周五";
    }else if (7){
        return @"周六";
    }else{
        return @"周日";
    }
}
@end
