//
//  EBConfig.h
//  PrictiseProduct
//
//  Created by JasonTang on 2018/8/1.
//  Copyright © 2018年 ___JasonTang___. All rights reserved.
//
//  环境配置项

#import <Foundation/Foundation.h>

/*=======================总开关===========================*/
#define DEV_ENV_0 //0:开发环境，1:测试环境,2:生产环境
//#define DEV_ENV_1
//#define DEV_ENV_2
/*=======================================================*/


/*----------------------开发环境配置-----------------------*/
#if defined(DEV_ENV_0)
#warning 当前配置为开发环境配置，生产时需要修改
#define NEED_CHECK_UPDATE NO

#define UAT_PC_Z //

/*----------------------测试环境配置-----------------------*/
#elif defined(DEV_ENV_1)
#warning 当前配置为测试配置，生产时需要修改
#define NEED_CHECK_UPDATE NO

#define UAT_PC_W  // 连UAT（外网）

/*----------------------生产环境配置-----------------------*/
#else
#define NEED_CHECK_UPDATE YES
//#define NSLog(...) //#warning 生产环境要屏蔽NSLog

#endif


extern NSString *const EBDefaultServerUrl;          // 环境地址
extern NSString *const EBDefaultServerUrlUAT;       // 根据时间切换的环境地址
extern NSString *const EBDefaultInformationUrl;     // 资讯地址
extern NSString *const EBDefaultInformationHTML;    // H5

extern NSString *const user_agent;          // 用户标识
extern NSString *const accept_value;        // 识别数据类型
extern NSString *const content_type;        // 内容数据类型
extern NSString *const EBConfigChannel;     // 应用渠道
extern NSString *const EBConfigTenantId;    // 公司机构号

extern NSString *const SIGN_KEY;            // sign标签 通过时间戳加密
extern NSString *const PASSWORD_KEY;        // 密码加密标签

extern NSString *const EB_QrCode_installation_URL;  //资讯分享-安装二维码地址
extern NSString *const EB_QrCode_invitation_URL;    //生成邀请二维码地址
extern NSString *const EB_UM_AppKey;                //友盟分享Key
extern NSString *const EB_UM_Sina_AppKey;
extern NSString *const EB_UM_Sina_AppSecret;
extern NSString *const EB_UM_QQ_AppId;
extern NSString *const EB_UM_QQ_AppKey;
extern NSString *const EB_UM_WX_AppID;
extern NSString *const EB_UM_WX_AppSecret;
extern NSString *const EB_UM_Share_Url;

extern NSString *const THIRDPARTYLOGINDISPLAYDATE;               // 生产测试环境切换的日期控制

extern NSInteger const EBConfigDefaultNetworkTimeOut;            // 网络请求超时的默认时间
extern NSInteger const EBConfigDefaultSMSCountDownTime;          // sms 重发时间
extern NSInteger const EBConfigUpFileNetworkTimeOut;             // 文件流类的网络请求超时时间
extern NSInteger const EBApplicationApsForProduction;            // 极光推送:开发环境：0 生产环境：1

extern NSInteger const EBConfigDefaultNSDecimalNumberScale;      // 默认保留金额多少位小数
extern BOOL const isNSDecimalNumberRounded;                      // YES:四舍五入 NO:截取

extern NSString *const EBConfigkSCPropNetProxiesHTTPProxy;       // 代理IP
extern NSString *const EBConfigkSCPropNetProxiesHTTPSProxy;      // 代理端口号


/*extern BOOL const defaultSSLMode;                              // SSL协议开关 默认为YES */

extern BOOL const isAllowInvalidCertificate;                     // 开发环境或生产环境开关

#define EB_SERVER_RET_CODE_Normal @"0"                           // 请求成功的标志
